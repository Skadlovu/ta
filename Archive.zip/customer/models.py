from django.db import models
from django.contrib.auth.models import User
from django.core.validators import RegexValidator
from django.utils import timezone
from datetime import timedelta
from decimal import Decimal
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator, MaxValueValidator




class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    verified = models.BooleanField(default=False)
    email_verified = models.BooleanField(default=False)
    first_name = models.CharField(max_length=200, blank=True, null=True)
    last_name = models.CharField(max_length=200, blank=True, null=True)
    identity_number = models.CharField(
        blank=True,
        null=True,
        max_length=13,
        validators=[RegexValidator(
            regex=r'^\+?1?\d{9,13}$',
            message="South African Identity Number."
        )]
    )
    cellphone_number = models.CharField(
        blank=True,
        null=True,
        max_length=10,
        validators=[RegexValidator(
            regex=r'^\+?1?\d{9,10}$',
            message="Phone number must be entered in the format: '00000000000'. Up to 10 digits allowed."
        )]
    )
    address = models.TextField(blank=True, null=True)
    profile_picture = models.ImageField(upload_to='user_pictures/', default='mountain.jpeg')
    date_of_birth = models.DateField(blank=True, null=True)
    emergency_contact_name = models.CharField(max_length=200, blank=True, null=True)
    emergency_contact_number = models.CharField(
        max_length=10,
        blank=True,
        null=True,
        validators=[RegexValidator(
            regex=r'^\+?1?\d{9,10}$',
            message="Phone number must be entered in the format: '00000000000'. Up to 10 digits allowed."
        )]
    )

    # Communication preferences
    receive_newsletters = models.BooleanField(default=False)
    receive_sms_alerts = models.BooleanField(default=False)

    # Basic metrics
    credit_score = models.IntegerField(default=0)
    date_joined = models.DateTimeField(default=timezone.now)
    last_login = models.DateTimeField(blank=True, null=True)

    # Event and ticket metrics
    total_events_attended = models.IntegerField(default=0)
    total_tickets_purchased = models.IntegerField(default=0)
    total_spent = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    average_ticket_price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    total_events_viewed = models.IntegerField(default=0)
    last_event_viewed = models.DateTimeField(blank=True, null=True)

    # Engagement metrics
    feedback_submitted = models.IntegerField(default=0)
    referral_count = models.IntegerField(default=0)
    profile_completion_percentage = models.IntegerField(default=0)
    membership_level = models.CharField(
        max_length=50,
        choices=[
            ('standard', 'Standard'),
            ('silver', 'Silver'),
            ('gold', 'Gold'),
        ],
        default='standard'
    )

    # Preferences
    user_preferences = models.JSONField(default=dict, blank=True, null=True)
    # Loyalty program audit


    class Meta:
        verbose_name = 'Customer'
        verbose_name_plural = 'Customers'
        ordering = ['-date_joined']


    def __str__(self):
        return f"{self.first_name} {self.last_name} - {self.user.username}"



class CustomerReward(models.Model):
    customer = models.OneToOneField(Customer, on_delete=models.CASCADE, related_name='rewards')

    # Point System
    points = models.IntegerField(default=0)
    lifetime_points = models.IntegerField(default=0)

    # Achievement Tracking
    events_milestone = models.IntegerField(default=0)
    referral_milestone = models.IntegerField(default=0)

    # Status System
    status_level = models.CharField(
        max_length=20,
        choices=[
            ('bronze', 'Bronze'),
            ('silver', 'Silver'),
            ('gold', 'Gold'),
            ('platinum', 'Platinum'),
        ],
        default='bronze'
    )

    # Non-monetary Perks
    early_access = models.BooleanField(default=False)
    priority_support = models.BooleanField(default=False)
    exclusive_events = models.BooleanField(default=False)
    vip_parking = models.BooleanField(default=False)

    # Engagement Multiplier
    engagement_multiplier = models.FloatField(default=1.0)

    class Meta:
        verbose_name = 'Customer Reward'
        verbose_name_plural = 'Customer Rewards'

    def calculate_status(self):
        # Update status based on lifetime points
        if self.lifetime_points >= 5000:
            self.status_level = 'platinum'
        elif self.lifetime_points >= 3000:
            self.status_level = 'gold'
        elif self.lifetime_points >= 1000:
            self.status_level = 'silver'
        else:
            self.status_level = 'bronze'
        self.update_perks()
        self.save()

    def update_perks(self):
        # Update perks based on status level
        if self.status_level == 'platinum':
            self.early_access = True
            self.priority_support = True
            self.exclusive_events = True
            self.vip_parking = True
            self.engagement_multiplier = 3.0
        elif self.status_level == 'gold':
            self.early_access = True
            self.priority_support = True
            self.exclusive_events = True
            self.vip_parking = False
            self.engagement_multiplier = 2.0
        elif self.status_level == 'silver':
            self.early_access = True
            self.priority_support = False
            self.exclusive_events = False
            self.vip_parking = False
            self.engagement_multiplier = 1.5
        else:  # bronze
            self.early_access = False
            self.priority_support = False
            self.exclusive_events = False
            self.vip_parking = False
            self.engagement_multiplier = 1.0

    def add_points(self, points, description="Points Earned"):
        # Add points and update status, logging the activity
        earned_points = int(points * self.engagement_multiplier)
        self.points += earned_points
        self.lifetime_points += earned_points
        self.calculate_status()

        # Log the activity
        RewardActivity.objects.create(
            customer=self.customer,
            points=earned_points,
            description=description,
            multiplier=self.engagement_multiplier
        )

    def redeem_points(self, points, description="Points Redeemed"):
        # Redeem points if available and log the redemption
        if self.points >= points:
            self.points -= points
            self.save()

            # Log the redemption
            RewardActivity.objects.create(
                customer=self.customer,
                points=-points,
                description=description,
                multiplier=1.0  # No multiplier for redemption
            )
            return True
        return False

    def __str__(self):
        return f"{self.customer.first_name}'s Rewards - {self.status_level.title()} Status"



class RewardActivity(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE, related_name='reward_activities')
    points = models.IntegerField()  # Positive for earned points, negative for redeemed points
    description = models.CharField(max_length=255)  # Brief description of the activity
    multiplier = models.FloatField(default=1.0)  # Engagement multiplier applied to the activity
    date = models.DateTimeField(default=timezone.now)  # Timestamp of the activity

    class Meta:
        verbose_name = 'Reward Activity'
        verbose_name_plural = 'Reward Activities'
        ordering = ['-date']

    def __str__(self):
        return f"{self.customer.user.username} - {self.description} ({self.points} points)"
