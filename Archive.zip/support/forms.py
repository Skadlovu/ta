from django import forms
from .models import OrganiserContactRequest
from crispy_forms.helper import FormHelper,Layout
from crispy_forms.layout import Field,Submit


class OrganiserContactRequestForm(forms.ModelForm):
    class Meta:
        model = OrganiserContactRequest
        fields = ['category', 'subject', 'message']
