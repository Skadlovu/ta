from django import forms
from django.contrib.auth.models import User
from .models import Organiser
from django import forms
from django.core.exceptions import ValidationError
import re


class OrganiserRegistrationForm(forms.ModelForm):
    email = forms.EmailField(required=True)
    password1 = forms.CharField(
        label="Password",
        widget=forms.PasswordInput,
        required=True
    )
    password2 = forms.CharField(
        label="Password confirmation",
        widget=forms.PasswordInput,
        required=True
    )

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    def __init__(self, *args, **kwargs):
        super(OrganiserRegistrationForm, self).__init__(*args, **kwargs)
        # Remove the help text from the password fields
        self.fields['password1'].help_text = None
        self.fields['password2'].help_text = None

        # Ensure no additional fields or messages are included
        for field_name in self.fields:
            self.fields[field_name].help_text = None  # Remove help text
            self.fields[field_name].label_suffix = ''  # Optional: remove colon after labels

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')

        if password1 and password2 and password1 != password2:
            raise ValidationError("Passwords do not match.")

        return cleaned_data

    def save(self, commit=True):
        # Save the User instance
        user = super(OrganiserRegistrationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.set_password(self.cleaned_data['password1'])  # Hash the password

        if commit:
            user.save()
        return user



class OrganiserProfileForm(forms.ModelForm):
    class Meta:
        model = Organiser
        fields = ['organisation','registration_number', 'telephone_number', 'address', 'profile_picture','financial_strength','experience_level', 'expected_ticket_volume','typical_ticket_price', 'social_media']



class BankForm(forms.ModelForm):
    class Meta:
        model = Organiser
        fields = ['bank_name', 'bank_account', 'bank_branch', 'bank_branch_code']

    def clean_bank_account(self):
        bank_account = self.cleaned_data.get('bank_account')

        # Ensure bank_account is a numeric value
        if not bank_account.isdigit():
            raise ValidationError("Bank account number must contain only digits.")

        # Convert to integer after validation and check if it’s positive
        bank_account = int(bank_account)
        if bank_account < 0:
            raise ValidationError("Bank account number cannot be negative.")

        return bank_account

    def clean_bank_branch_code(self):
        bank_branch_code = self.cleaned_data.get('bank_branch_code')

        # Ensure branch code is a valid integer within the 6-digit range
        try:
            bank_branch_code = int(bank_branch_code)
        except ValueError:
            raise ValidationError("Branch code must be a 6-digit number.")

        if not (100000 <= bank_branch_code <= 999999):
            raise ValidationError("Branch code must be a 6-digit number.")

        return bank_branch_code

    def clean_bank_name(self):
        bank_name = self.cleaned_data.get('bank_name')

        # Validate that the bank name contains only letters and spaces
        if not re.match(r'^[A-Za-z\s]+$', bank_name):
            raise ValidationError("Bank name must contain only letters and spaces.")

        return bank_name

    def clean_bank_branch(self):
        bank_branch = self.cleaned_data.get('bank_branch')

        # Validate that the branch name contains only letters and spaces
        if not re.match(r'^[A-Za-z\s]+$', bank_branch):
            raise ValidationError("Branch name must contain only letters and spaces.")

        return bank_branch
