import datetime
from django.conf import settings
from django.core.mail import send_mail

def validate_id_number(id_number):
    """
    Validate a South African ID number.
    
    :param id_number: A string representing the 13-digit South African ID number.
    :return: True if the ID number is valid, False otherwise.
    """
    if len(id_number) != 13 or not id_number.isdigit():
        return False
    
    # Extract components
    date_of_birth = id_number[:6]
    check_digit = int(id_number[-1])
    
    # Validate the date of birth
    try:
        year = int(date_of_birth[:2])
        month = int(date_of_birth[2:4])
        day = int(date_of_birth[4:])
        
        if year < 22:  # Assuming current year is 2024, adjust as needed
            year += 2000
        else:
            year += 1900
            
        datetime.datetime(year, month, day)  # This will raise ValueError if invalid date
        
    except ValueError:
        return False
    
    # Luhn Algorithm for check digit validation
    def luhn_algorithm(id_number):
        total_sum = 0
        reverse_digits = id_number[-2::-1]
        
        for i, digit in enumerate(reverse_digits):
            num = int(digit)
            if i % 2 == 0:  # Double every second digit
                num *= 2
                if num > 9:
                    num -= 9
            total_sum += num
        
        return (total_sum + check_digit) % 10 == 0
    
    return luhn_algorithm(id_number)



def send_cancellation_email(ticket_holder):
    """Send email to user and organizer about the ticket cancellation."""
    send_mail(
        subject='Your Ticket Has Been Canceled',
        message=f'Ticket {ticket_holder.ticket_details.class_name} for {ticket_holder.ticket_details.event.title} has been canceled.',
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[ticket_holder.ticket_sales.customer.email, ticket_holder.ticket_details.event.organiser.user.email],
        fail_silently=False,
    )


"""
 id_number = forms.CharField(max_length=13)

    def clean_id_number(self):
        id_number = self.cleaned_data.get('id_number')
        if not validate_id_number(id_number):
            raise forms.ValidationError("Invalid South African ID number.")
        return id_number
"""
