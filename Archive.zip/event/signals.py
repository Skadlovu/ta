from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Event
from .create_portrait import create_portrait
from .create_landscape import create_landscape

@receiver(post_save, sender=Event)
def create_event_images(sender, instance, created, **kwargs):
    if created:
        create_portrait(instance)
        create_landscape(instance)
