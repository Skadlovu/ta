from django.shortcuts import render, redirect,get_object_or_404,HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from .models import Organiser
from .forms import OrganiserRegistrationForm, OrganiserProfileForm,BankForm
from django.core.mail import send_mail,EmailMessage,EmailMultiAlternatives
from django.conf import settings
from django.contrib.auth import views as auth_views
from .models import Organiser,SalesReport
from ticket.models import TicketSales,TicketHolder,TicketDetails
from decimal import Decimal
from event.forms import EventForm, TicketDetailsFormSet,PerformerFormSet
from django.contrib.auth.forms import AuthenticationForm
from event.models import Event,SubCategory
from django.contrib.auth import login as auth_login
from django.conf import settings
from django.urls import reverse,reverse_lazy
from django.http import JsonResponse
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.db.models import Count, Sum
from django.db.models.functions import TruncMonth,TruncDay,TruncWeek
from django.utils import timezone
from datetime import timedelta,datetime
from django.db.models import Q
from django.utils.decorators import method_decorator
from django.views.generic import TemplateView
from support.forms import OrganiserContactRequestForm
from support.models import OrganiserContactRequest
from django.contrib import messages
from rest_framework import status
from django.db.models import DecimalField
import csv
from django.core.paginator import Paginator
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.tokens import default_token_generator
from django.db import transaction
from django.core.exceptions import ObjectDoesNotExist
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
import logging
from django.db.models import Sum, Count, Avg, F, ExpressionWrapper, FloatField
from django.db.models.functions import ExtractMonth, TruncMonth
from django.db import models

logger = logging.getLogger(__name__)

@login_required
def support(request):
    organiser = request.user.organiser  # Ensure this relationship exists
    if request.method == 'POST':
        form = OrganiserContactRequestForm(request.POST)
        if form.is_valid():
            contact_request = form.save(commit=False)
            contact_request.organiser = organiser
            contact_request.save()
            messages.success(request, 'Your support request has been submitted successfully.')
            return redirect('organiser:support')
    else:
        form = OrganiserContactRequestForm()

    previous_requests = OrganiserContactRequest.objects.filter(organiser=organiser).order_by('-created_at')

    context = {
        'form': form,
        'organiser': organiser,
        'previous_requests': previous_requests,
    }

    return render(request, 'organiser/support.html', context)

def knowledge_base(request):
    organiser = None
    if request.user.is_authenticated:
        try:
            organiser = Organiser.objects.get(user=request.user)
        except Organiser.DoesNotExist:
            organiser = None

    # Determine the base template based on authentication
    base_template = 'base1.html' if request.user.is_authenticated else 'base.html'

    context = {
        'organiser': organiser,
        'base_template': base_template
    }
    return render(request, 'organiser/knowledge.html', context)


@login_required
def bank_view(request):
    try:
        organiser = request.user.organiser  # Assume that every organiser has a User
    except Organiser.DoesNotExist:
        # Redirect or handle if the organiser profile doesn't exist
        messages.error(request, "Organiser profile not found. Please contact support.")
        return redirect('organiser:profile')  # Redirect to profile or error page

    if request.method == 'POST':
        form = BankForm(request.POST, instance=organiser)

        if form.is_valid():
            bank_account = form.save(commit=False)

            # Ensure the organiser instance is associated with the user
            if bank_account.user_id is None:
                bank_account.user = request.user

            bank_account.save()
            messages.success(request, 'Banking information updated successfully!')
            return redirect('organiser:registration_complete')  # Redirect to the next step
    else:
        form = BankForm(instance=organiser)

    context = {
        'form': form,
        'title': 'Organiser Banking Information',
        'organiser':organiser
    }
    return render(request, 'organiser/bank_form.html', context)

@login_required
def bank_list(request, organiser_id):
    organiser = get_object_or_404(Organiser, id=organiser_id)

    bank_details = {
        'bank_name': organiser.bank_name,
        'bank_account': organiser.bank_account,
        'bank_branch': organiser.bank_branch,
        'bank_branch_code': organiser.bank_branch_code,
    }

    return render(request, 'organiser/bank_details.html', {
        'organiser': organiser,
        'bank_details': bank_details,
    })

@login_required
def organiser_statistics(request):
    organiser = request.user.organiser
    now = timezone.now()  # Ensure 'now' is a datetime.datetime object

    # Define date ranges
    last_24_hours = now - timedelta(days=1)
    last_7_days = now - timedelta(days=7)
    last_30_days = now - timedelta(days=30)

    # Utility function to get revenue data for daily, weekly, and monthly intervals
    def get_revenue_data(interval):
        if interval == 'daily':
            range_end = now - timedelta(days=6)  # Past 7 days
            trunc_function = TruncDay
        elif interval == 'weekly':
            range_end = now - timedelta(weeks=3)  # Past 4 weeks
            trunc_function = TruncWeek
        elif interval == 'monthly':
            range_end = now - timedelta(days=89)  # Past 3 months
            trunc_function = TruncMonth

        sales = (
            TicketSales.objects.filter(organiser=organiser, purchase_date__gte=range_end)
            .annotate(interval=trunc_function('purchase_date'))
            .values('interval')
            .annotate(total=Sum('total_price'))
            .order_by('interval')
        )

        labels = [sale['interval'].strftime('%Y-%m-%d') for sale in sales]
        data = [sale['total'] or 0 for sale in sales]
        return labels, data

    # Daily, weekly, and monthly sales data
    daily_labels, daily_data = get_revenue_data('daily')
    weekly_labels, weekly_data = get_revenue_data('weekly')
    monthly_labels, monthly_data = get_revenue_data('monthly')

    # Aggregated revenue summaries
    def calculate_revenue(date_from=None):
        queryset = TicketSales.objects.filter(organiser=organiser)
        if date_from:
            queryset = queryset.filter(purchase_date__gte=date_from)
        total_revenue = queryset.aggregate(total=Sum('total_price'))['total'] or 0
        return total_revenue

    lifetime_revenue = calculate_revenue()
    revenue_30_days = calculate_revenue(last_30_days)
    revenue_7_days = calculate_revenue(last_7_days)
    revenue_24_hours = calculate_revenue(last_24_hours)

    # Ticket statistics
    ticket_classes = TicketDetails.objects.filter(event__organiser=organiser)
    tickets_data = []
    for ticket_class in ticket_classes:
        tickets_data.append({
            'title':ticket_class.event.title,
            'class_name': ticket_class.class_name,
            'price': ticket_class.price,
            'total': ticket_class.number_of_tickets,
            'sold': ticket_class.tickets_sold,
            'remaining': ticket_class.tickets_remaining,
        })

    # Active event details
    active_events = Event.objects.filter(organiser=organiser, event_date__gte=now)
    events_data = []
    for event in active_events:
        # Convert event_date to datetime to ensure type consistency
        event_datetime = timezone.make_aware(datetime.combine(event.event_date, datetime.min.time()))
        total_capacity = sum(t.number_of_tickets for t in event.ticket_details.all())
        total_sold = sum(t.tickets_sold for t in event.ticket_details.all())
        capacity_percentage = (total_sold / total_capacity * 100) if total_capacity > 0 else 0
        events_data.append({
            'title': event.title,
            'days_left': (event_datetime - now).days,
            'capacity_percentage': capacity_percentage,
        })

    # Pass data to the template
    context = {
        'lifetime_revenue': lifetime_revenue,
        'revenue_30_days': revenue_30_days,
        'revenue_7_days': revenue_7_days,
        'revenue_24_hours': revenue_24_hours,
        'daily_labels': daily_labels,
        'daily_data': daily_data,
        'weekly_labels': weekly_labels,
        'weekly_data': weekly_data,
        'monthly_labels': monthly_labels,
        'monthly_data': monthly_data,
        'tickets_data': tickets_data,
        'events_data': events_data,
        'organiser': organiser,
    }

    return render(request, 'organiser/statistics.html', context)

@login_required
def organiser_dashboard(request):
    # Get organiser
    organiser = request.user.organiser
    today = timezone.now()
    thirty_days_ago = today - timedelta(days=30)

    # Calculate metrics
    total_revenue = TicketSales.objects.filter(
        organiser=organiser,
        purchase_date__gte=thirty_days_ago
    ).aggregate(total=Sum('total_price'))['total'] or 0

    total_tickets_sold = TicketHolder.objects.filter(
        ticket_sales__organiser=organiser
    ).count()

    active_events_count = Event.objects.filter(
        organiser=organiser,
        event_date__gte=today
    ).count()

    # Calculate attendance rate (if you have attendance tracking)
    attendance_rate = 85  # Placeholder - implement actual calculation based on your attendance tracking

    # Get sales trend data (last 7 days)
    sales_trend = TicketSales.objects.filter(
        organiser=organiser,
        purchase_date__gte=today - timedelta(days=7)
    ).values('purchase_date__date').annotate(
        daily_sales=Sum('total_price')
    ).order_by('purchase_date__date')

    sales_trend_labels = [s['purchase_date__date'].strftime('%Y-%m-%d') for s in sales_trend]
    sales_trend_data = [float(s['daily_sales']) for s in sales_trend]

    # Get ticket distribution data
    ticket_distribution = TicketHolder.objects.filter(
        ticket_sales__organiser=organiser
    ).values('ticket_details__class_name').annotate(
        count=Count('id')
    )

    ticket_distribution_labels = [t['ticket_details__class_name'] for t in ticket_distribution]
    ticket_distribution_data = [t['count'] for t in ticket_distribution]

    # Get recent sales
    recent_sales = TicketSales.objects.filter(
        organiser=organiser
    ).order_by('-purchase_date')[:5]

    # Get upcoming events
    upcoming_events = Event.objects.filter(
        organiser=organiser,
        event_date__gte=today
    ).order_by('-event_date')[:5]

    context = {
        'organiser': organiser,
        'total_revenue': total_revenue,
        'total_tickets_sold': total_tickets_sold,
        'active_events_count': active_events_count,
        'attendance_rate': attendance_rate,
        'sales_trend_labels': sales_trend_labels,
        'sales_trend_data': sales_trend_data,
        'ticket_distribution_labels': ticket_distribution_labels,
        'ticket_distribution_data': ticket_distribution_data,
        'recent_sales': recent_sales,
        'upcoming_events': upcoming_events,
    }

    return render(request, 'organiser/dashboard.html', context)


def load_subcategories(request):
    category_id = request.GET.get('category_id')
    subcategories = SubCategory.objects.filter(category_id=category_id).values('id', 'name')
    return JsonResponse(list(subcategories), safe=False)

@login_required
def create_event(request):
    organiser = Organiser.objects.get(user=request.user)

    # Ensure that the organiser is approved
    if not organiser.approved:
        return redirect('organiser:dashboard')

    if request.method == 'POST':
        event_form = EventForm(request.POST, request.FILES)
        # Pass instance as None initially
        ticket_formset = TicketDetailsFormSet(request.POST, request.FILES, prefix='tickets')
        performer_formset = PerformerFormSet(request.POST, request.FILES, prefix='performers')

        if event_form.is_valid() and ticket_formset.is_valid() and performer_formset.is_valid():
            # Save the event instance first
            event = event_form.save(commit=False)
            event.organiser = organiser  # Assign the organiser
            event.save()

            # Save the related forms with the correct instance
            ticket_formset.instance = event
            ticket_formset.save()

            performer_formset.instance = event
            performer_formset.save()




            return redirect('organiser:dashboard')
    else:
        event_form = EventForm()
        ticket_formset = TicketDetailsFormSet(prefix='tickets')
        performer_formset = PerformerFormSet(prefix='performers')

    return render(request, 'organiser/create_event.html', {
        'event_form': event_form,
        'ticket_formset': ticket_formset,
        'performer_formset': performer_formset,
        'organiser': organiser
    })



@login_required
def edit_event(request, event_slug):
    organiser = Organiser.objects.filter(user=request.user).first()
    if not organiser:
        messages.error(request, 'Organiser account not found.')
        return redirect('organiser:dashboard')

    if not organiser.approved:
        return redirect('organiser:dashboard')

    # Retrieve the event by slug and organiser to verify ownership
    event = get_object_or_404(Event, slug=event_slug, organiser=organiser)

    if request.method == 'POST':
        event_form = EventForm(request.POST, request.FILES, instance=event)
        ticket_formset = TicketDetailsFormSet(
            request.POST,
            request.FILES,
            prefix='tickets',
            instance=event
        )
        performer_formset = PerformerFormSet(
            request.POST,
            request.FILES,
            prefix='performers',
            instance=event
        )

        if event_form.is_valid() and ticket_formset.is_valid() and performer_formset.is_valid():
            event = event_form.save(commit=False)
            event.organiser = organiser  # Ensure organiser is still set
            event.save()

            # Save the related forms
            ticket_formset.save()
            performer_formset.save()

            messages.success(request, 'Event updated successfully!')
            return redirect('organiser:dashboard')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        event_form = EventForm(instance=event)
        ticket_formset = TicketDetailsFormSet(prefix='tickets', instance=event)
        performer_formset = PerformerFormSet(prefix='performers', instance=event)

    return render(request, 'organiser/edit_event.html', {
        'event_form': event_form,
        'ticket_formset': ticket_formset,
        'performer_formset': performer_formset,
        'organiser': organiser,
        'event': event
    })




def organiser_registration(request):
    if request.method == 'POST':
        form = OrganiserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            send_verification_email(user,request)
            return redirect('organiser:email_notice')
    else:
        form = OrganiserRegistrationForm()
    return render(request, 'organiser/registration.html', {'form': form})


def registration_complete(request):
    organiser = Organiser.objects.get(user=request.user)
    return render(request, 'organiser/registration_complete.html',{'organiser':organiser})

def verify_email_notice(request):
    return render(request, 'organiser/email_notice.html')

@login_required
def organiser_profile(request):
    try:
        organiser = Organiser.objects.get(user=request.user)
    except Organiser.DoesNotExist:
        return redirect('some_error_page')  # Handle case where organiser profile doesn't exist

    if request.method == 'POST':
        form = OrganiserProfileForm(request.POST, request.FILES, instance=organiser)
        if form.is_valid():
            with transaction.atomic():
                # Store the initial completion status
                was_previously_complete = organiser.is_profile_complete

                # Save the form first
                organiser = form.save(commit=False)

                # Check if profile is complete after new data
                if _is_profile_complete(organiser):
                    organiser.is_profile_complete = True
                    organiser.save()

                    # Only redirect to completion page if this is the first time completing
                    if not was_previously_complete:
                        messages.success(request, 'Profile completed successfully!')
                        return redirect('organiser:banking')
                    else:
                        messages.success(request, 'Profile updated successfully!')
                        return redirect('organiser:profile')
                else:
                    organiser.is_profile_complete = False
                    organiser.save()
                    messages.warning(request, 'Please fill in all required fields to complete your profile.')
    else:
        form = OrganiserProfileForm(instance=organiser)

    return render(request, 'organiser/profile.html', {
        'form': form,
        'organiser': organiser,
    })

def _is_profile_complete(organiser):
    """
    Check if all required profile fields are filled out.
    Returns True if all required fields have valid values, False otherwise.

    Args:
        organiser (Organiser): The organiser instance to check

    Returns:
        bool: True if profile is complete, False otherwise
    """
    required_fields = [
        organiser.organisation,
        organiser.telephone_number,
        organiser.address,
        organiser.financial_strength,
        organiser.experience_level,
        organiser.expected_ticket_volume
    ]

    # Check that none of the required fields are None or empty strings
    return all(bool(field) for field in required_fields)

@login_required
def profile_list(request, organiser_id):
    organiser = get_object_or_404(Organiser, id=organiser_id)

    profile_details = {
        'organisation':organiser.organisation,
        'cellphone_number':organiser.cellphone_number,
        'address':organiser.address,
        'profile_picture':organiser.profile_picture,
        'social_media':organiser.social_media
    }

    return render(request, 'organiser/profile_details.html', {
        'organiser': organiser,
        'profile_details': profile_details,
    })


def organiser_login(request):
    # Redirect if user is already logged in
    if request.user.is_authenticated:
        try:
            organiser = request.user.organiser
            # Check profile completion and redirect accordingly
            if not organiser.is_profile_complete:
                messages.warning(request, 'Please complete your profile information.')
                return redirect('organiser:organiser_profile')
            elif not organiser.is_profile_complete:
                messages.warning(request, 'Please complete your banking information.')
                return redirect('organiser:banking')
            return redirect('organiser:registration_complete')  # Final redirect if all complete
        except ObjectDoesNotExist:
            messages.error(request, 'Organiser profile not found. Please contact support.')
            return redirect('organiser:login')

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)

        if form.is_valid():
            user = form.get_user()

            try:
                organiser = user.organiser  # Get organiser profile

                # Check email verification
                if not organiser.is_email_verified:
                    messages.warning(request,
                        'Please verify your email before logging in. '
                        'Need a new verification link? '
                        '<a href="/resend-verification">Click here</a>'
                    )
                    return redirect('organiser:login')

                # If email is verified, log them in
                auth_login(request, user)
                messages.success(request, f'Welcome back, {organiser.organisation}!')

                # Check profile completion and redirect accordingly
                if not organiser.is_profile_complete:
                    return redirect('organiser:organiser_profile')
                elif not organiser.is_profile_complete:
                    return redirect('organiser:banking')
                else:
                    return redirect('organiser:registration_complete')

            except ObjectDoesNotExist:
                messages.error(
                    request,
                    'No organiser profile found for this account. '
                    'If you believe this is an error, please contact support.'
                )
                return redirect('organiser:login')

        else:
            # Handle invalid form (wrong credentials)
            messages.error(
                request,
                'Invalid username or password. Please try again.'
            )

    else:
        form = AuthenticationForm()

    context = {
        'form': form,
        'title': 'Organiser Login',
        'next': request.GET.get('next', '')  # Handle next parameter if present
    }
    return render(request, 'organiser/login.html', context)


def _is_profile_complete(organiser):
    """
    Check if all required profile and banking fields are filled out.
    Returns True if all required fields have valid values, False otherwise.

    Args:
        organiser (Organiser): The organiser instance to check

    Returns:
        bool: True if profile and banking info is complete, False otherwise
    """
    PROFILE_FIELDS = [
    'organisation',
    'telephone_number',
    'address',
    'financial_strength',
    'experience_level',
    'expected_ticket_volume'
    ]

    BANKING_FIELDS = [
    'bank_name',
    'bank_account',
    'bank_branch',
    'bank_branch_code'
    ]
    # Retrieve field values from the organiser instance based on the constants
    profile_values = [getattr(organiser, field) for field in PROFILE_FIELDS]
    banking_values = [getattr(organiser, field) for field in BANKING_FIELDS]

    # Check that all fields are not None or empty strings
    return all(bool(value) for value in profile_values + banking_values)

"""
def login_view(request):
    return auth_views.LoginView.as_view(template_name='organiser/login.html')(request)
"""
def logout_view(request):
    # Redirect to a different page after logout
    return auth_views.LogoutView.as_view(
        template_name='organiser/logged_out.html',
        next_page=reverse_lazy('organiser:login')  # Redirect to the 'home' view after logout
    )(request)


def export_sales_report_csv(request, organiser_id):
    if not request.user.is_authenticated or request.user.organiser.id != organiser_id:
        return HttpResponse(status=403)

    organiser = get_object_or_404(Organiser, pk=organiser_id)
    reports = SalesReport.objects.filter(organiser=organiser).order_by('-generated_on')

    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="{organiser.user.username}_sales_report.csv"'

    writer = csv.writer(response)
    writer.writerow(['Generated On', 'Total Revenue', 'Total Tickets Sold', 'Details'])

    for report in reports:
        writer.writerow([
            report.generated_on.strftime('%Y-%m-%d %H:%M:%S'),
            f"${report.total_revenue:.2f}",
            report.total_tickets_sold,
            report.report_details
        ])

    return response

def generate_sales_report(organiser, start_time, end_time):
    try:
        # Filter ticket sales within the date range
        sales_query = TicketSales.objects.filter(
            organiser=organiser,
            purchase_date__range=(start_time, end_time)
        )

        total_revenue = sales_query.aggregate(
            Sum('total_price')
        )['total_price__sum'] or Decimal('0.00')

        total_tickets = TicketHolder.objects.filter(
            ticket_sales__in=sales_query
        ).count()

        # Detailed breakdown by ticket class
        details = (
            TicketHolder.objects
            .filter(ticket_sales__in=sales_query)
            .values('ticket_details__class_name')
            .annotate(
                total_sold=Sum('ticket_sales__quantity'),
                revenue=Sum('ticket_sales__total_price')
            )
        )

        # Store the report
        return SalesReport.objects.create(
            organiser=organiser,
            total_revenue=total_revenue,
            total_tickets_sold=total_tickets,
            report_details=list(details)
        )
    except Exception as e:
        print(f"Error generating report: {str(e)}")
        return None

def organiser_sales_report_view(request):
    if not request.user.is_authenticated:
        return redirect('login')

    organiser = request.user.organiser
    reports_per_page = int(request.GET.get('per_page', 7))
    page_number = request.GET.get('page', 1)

    # Get date range filters
    start_date = request.GET.get('start_date')
    end_date = request.GET.get('end_date')

    # Base query
    reports = SalesReport.objects.filter(organiser=organiser)

    # Apply date filters if provided
    if start_date and end_date:
        try:
            start_dt = datetime.strptime(start_date, '%Y-%m-%d')
            end_dt = datetime.strptime(end_date, '%Y-%m-%d')
            reports = reports.filter(generated_on__range=[start_dt, end_dt])
        except ValueError:
            messages.error(request, 'Invalid date format. Please use YYYY-MM-DD.')

    reports = reports.order_by('-generated_on')

    # Handle AJAX request for report data
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        paginator = Paginator(reports, reports_per_page)
        page_obj = paginator.get_page(page_number)

        return JsonResponse({
            'reports': [{
                'id': report.id,
                'generated_on': report.generated_on.strftime('%Y-%m-%d %H:%M:%S'),
                'total_revenue': f"${report.total_revenue:.2f}",
                'total_tickets_sold': report.total_tickets_sold
            } for report in page_obj],
            'has_next': page_obj.has_next(),
            'has_previous': page_obj.has_previous(),
            'total_pages': paginator.num_pages
        })

    # Regular page load
    paginator = Paginator(reports, reports_per_page)
    page_obj = paginator.get_page(page_number)

    context = {
        'reports': page_obj,
        'reports_per_page': reports_per_page,
        'start_date': start_date,
        'end_date': end_date,
        'organiser':organiser,
    }
    return render(request, 'organiser/reports.html', context)

def download_report_csv(request, report_id):
    report = get_object_or_404(SalesReport, id=report_id)

    # Check permissions
    if not request.user.is_authenticated or request.user.organiser != report.organiser:
        return HttpResponse(status=403)

    try:
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = f'attachment; filename="sales_report_{report.generated_on.strftime("%Y%m%d")}.csv"'

        writer = csv.writer(response)
        writer.writerow(['Class Name', 'Total Sold', 'Revenue'])

        for detail in report.report_details:
            writer.writerow([
                detail['ticket_details__class_name'],
                detail['total_sold'],
                f"${detail['revenue']:.2f}"
            ])

        return response
    except Exception as e:
        messages.error(request, f'Error downloading report: {str(e)}')
        return redirect('organiser_sales_report_view')

def email_report(request, report_id):
    report = get_object_or_404(SalesReport, id=report_id)

    # Check permissions
    if not request.user.is_authenticated or request.user.organiser != report.organiser:
        return HttpResponse(status=403)

    try:
        organiser_email = report.organiser.user.email

        # Generate CSV content
        csv_response = download_report_csv(request, report_id)

        email = EmailMessage(
            subject='Your Sales Report',
            body=f"Please find attached the sales report generated on {report.generated_on.strftime('%Y-%m-%d %H:%M:%S')}.",
            from_email='noreply@eventapp.com',
            to=[organiser_email],
        )

        email.attach(
            f"sales_report_{report.generated_on.strftime('%Y%m%d')}.csv",
            csv_response.content,
            'text/csv'
        )

        email.send(fail_silently=False)
        messages.success(request, 'Report emailed successfully.')

    except Exception as e:
        messages.error(request, f'Error sending email: {str(e)}')

    return redirect('organiser_sales_report_view')




def send_verification_email(user, request):
    token = default_token_generator.make_token(user)
    uid = urlsafe_base64_encode(force_bytes(user.pk))

    # Construct the verification link
    verification_link = request.build_absolute_uri(
        reverse('organiser:verify_email', kwargs={'uidb64': uid, 'token': token})
    )

    # Render HTML content for the email
    html_content = render_to_string('organiser/email_verification.html', {
        'user': user,
        'verification_link': verification_link
    })

    subject = 'Verify your email address'
    from_email = settings.DEFAULT_FROM_EMAIL
    to = [user.email]

    # Create an email with both plain text and HTML parts
    email = EmailMultiAlternatives(subject, '', from_email, to)
    email.attach_alternative(html_content, "text/html")
    email.send(fail_silently=False)



def verify_email(request, uidb64, token):
    try:
        # Decode the user ID and fetch the user
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = get_object_or_404(User, pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and default_token_generator.check_token(user, token):
        # Get or create the UserProfile
        organiser, created = Organiser.objects.get_or_create(user=user)
        organiser.is_email_verified = True
        organiser.save()

        messages.success(request, 'Email verified! Please log in and complete your profile.')
        return redirect('organiser:login')
    else:
        # Invalid token or user not found, handle the error
        messages.error(request, 'Invalid or expired verification link. Please try again.')
        return redirect('organiser:login')

@login_required
def organiser_events(request):
    organiser = get_object_or_404(Organiser,user=request.user)
    """List all events created by the organiser"""
    events_list = Event.objects.filter(
        organiser=request.user.organiser
    ).order_by('-date_posted')

    # Pagination
    paginator = Paginator(events_list, 15)  # Show 15 events per page
    page = request.GET.get('page')

    try:
        events = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page
        events = paginator.page(1)
    except EmptyPage:
        # If page is out of range, deliver last page of results
        events = paginator.page(paginator.num_pages)

    context = {
        'organiser':organiser,
        'events': events,
        'total_events': events_list.count(),
        'active_events': events_list.filter(active=True).count(),
    }
    return render(request, 'organiser/events.html', context)


@login_required
def event_detail(request, slug):
    """Show detailed view of a specific event"""
    organiser = get_object_or_404(Organiser,user=request.user)
    event = get_object_or_404(
        Event,
        slug=slug,
        organiser=request.user.organiser
    )

    context = {
        'organiser':organiser,
        'event': event,

    }
    return render(request, 'organiser/event.html', context)\



def event_toggle_status(request, event_slug):
    event = get_object_or_404(Event, slug=event_slug)

    # Toggle the status of the event
    if event.active:
        event.active = False
        messages.success(request, f"The event '{event.title}' has been deactivated.")
    else:
        event.active = True
        messages.success(request, f"The event '{event.title}' has been activated.")

    event.save()

    # Redirect to the event detail page or any other page
    return redirect('organiser:my_event', event.slug)