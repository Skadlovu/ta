from django.urls import path
from . import views

#app_name = 'blog'

urlpatterns = [
    path('linkup/news/stories', views.blog_list, name='news'),
    path('linkup/news/category/', views.blog_list, name='news_category'),
    path('linkup/news/story/<slug:slug>/', views.blog_detail, name='news_detail'),
    path('linkup/news/category/list/slug:slug/', views.category_detail, name='news_category_list'),
]