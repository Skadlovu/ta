from django import forms
from .models import Event, Performer,SubCategory
from django.forms import inlineformset_factory
from ticket.models import TicketDetails
from ckeditor.widgets import CKEditorWidget


class EventForm(forms.ModelForm):
    class Meta:
        model = Event
        fields = ['title', 'description', 'poster', 'category', 'event_date', 'address', 'venue', 'event_time']
        widgets = {
            'content': CKEditorWidget(),
        }


TicketDetailsFormSet = inlineformset_factory(Event, TicketDetails, fields=['class_name', 'price', 'number_of_tickets'], extra=1, can_delete=True)
PerformerFormSet = inlineformset_factory(Event, Performer, fields=['entertainer'], extra=1, can_delete=True)